# MiniShop Pi

Site de démonstration pour MiniShop Pi.

## Contenu
- `index.html` → Page principale
- `style.css` → Styles du site
- `script.js` → Script pour les interactions simples

## Instructions pour GitHub
1. Crée un nouveau dépôt sur GitHub.
2. Copie tous les fichiers dans ce dépôt.
3. Clique sur "Commit changes" pour les publier.
4. Active GitHub Pages dans les paramètres du dépôt pour voir le site en ligne.

---
👉 Exemple de lien une fois publié :  
https://tonpseudo.github.io/pi-minishop-site/
