function ajouterPanier(produit) {
    alert(produit + " a été ajouté au panier !");
}
